---
title: Steak and Wine Pie
slug: steak-and-wine-pie
source_url: https://en.wikibooks.org/wiki/Cookbook:Steak_and_Wine_Pie
source: Wikibooks Cookbook
license: CC-BY-SA 3.0
wikibooks_id: 480517
date: '2025-12-08'
cuisine: []
course: []
diet: []
difficulty: ''
technique: []
recipe_type: []
ingredients: []
---

# Steak and Wine Pie

This **steak and wine pie** is a variation on the Steak and Ale Pie recipe, one with a richer and more fruity sauce and a more crumbly, stiffer crust.

## Ingredients

### Pie dough

- 3 tbsp butter or margarine, cut into small cubes
- 5 tbsp all-purpose flour
- 1 handful dry Italian seasoning
- Salt to taste

### Meat

- ¼ cup olive oil
- ¼ cup red wine or lemon juice
- ¼ cup soy sauce
- 1 lb beef chuck rib

### Filling

- ½ tbsp butter or margarine
- 1 bay leaf
- Thyme (fresh or dried) to taste
- Basil (preferably dried) to taste
- ½ stalk celery, sliced ⅛ inch thick
- ⅓ whole carrot, sliced ⅛ inch thick, then cut into semicircles
- ½ small onion, diced
- ⅞ cup red wine
- 1 tbsp Worcestershire sauce
- 1 tbsp gravy granules
- 1 tbsp tomato ketchup
- Salt
- Pepper

## Equipment

- 13-cm- or 5-inch-diameter pie plate or ceramic bowl
- Saucepan
- Brush
- Rolling pin
- Spoons, cutlery and spatula, as needed
- Oven or toaster oven (preferred)

## Procedure

### For the dough

1. Combine the flour, salt, and Italian seasoning in a shallow bowl, and mix to distribute well. Mix in the butter until solid, firm dough lumps form. If mixing by hand, pinch and clasp them together until a ball can be formed.
2. Dust a work surface and the dough ball with a little flour to prevent sticking. Flatten dough with a rolling pin until it forms a thin disk large enough to be draped over the pie plate or bowl.
3. Freeze the dough for 20 minutes, or for the duration of filling prep and cooking.

### Filling

1. Combine the oil, wine, and soy sauce to make a marinade. Submerge the beef in the marinade, and let this marinate in the fridge for 24 hours.
2. Remove the meat from the marinade, and slice it ¼ inch thick.
3. Heat the saucepan over high heat, then add the butter and let it melt.
4. Add the sliced beef to the saucepan. Sauté, stirring, until browned all over.
5. Add bay leaf, thyme, basil, celery, onion, and carrot. Sauté, stirring occasionally, until onions and celery are soft.
6. Scrape some of the fond off the pan bottom without taking it out, if possible. Stir in the wine, Worcestershire sauce, and gravy granules for 1 minute
7. Turn heat to low, stir in ketchup, and cover the pan. Cook until stew volume is reduced by a third to half and liquids are beginning to thicken.
8. Season with salt and pepper to taste.
9. Remove from the heat, and discard the bay leaf.

### Assembly and final baking

1. Pour filling into the pie plate or bowl.
2. Cover with the pie crust disk and press around edges to seal. The dough falling apart is acceptable as long as it retains an amount of crunch or flakiness.
3. Bake at 445 °F (230 °C / Gas 8) for 10 to 15 minutes or until top crust turns medium brown. Handle with care.

## Notes, tips, and variations

- The butter/margarine can be substituted by 2 tbsp olive oil mixed with 1 tbsp milk.
- The gravy granules can be substituted by 1 tsp beef bouillon mixed with 2 tsp hot water.
- If you want a bottom crust for the pie, double the dough quantities, and divide the dough in half before rolling out each portion. Grease the baking dish and line it with one of the dough disks before freezing and filling.
- You can also slice the steak before marinating it in order to facilitate the flavor permeation. You may not need to marinate for as long if you do so.

## See also

- Cookbook:Chicken Pot Pie I
- Cookbook:Pork Pot Pie
- Cookbook:Steak and Ale Pie
