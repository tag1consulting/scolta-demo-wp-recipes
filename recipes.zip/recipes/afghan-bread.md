---
title: Afghan Bread
slug: afghan-bread
source_url: https://en.wikibooks.org/wiki/Cookbook:Afghan_Bread
source: Wikibooks Cookbook
license: CC-BY-SA 3.0
wikibooks_id: 96869
date: '2025-07-22'
cuisine:
- Afghan
- Pashtun
course: []
diet:
- Vegetarian
difficulty: Medium Difficulty
technique:
- Baking
recipe_type:
- flatbread
ingredients:
- all-purpose flour
- corn oil
- egg yolk
- sugar
categories:
- Afghan recipes
- Baking recipes
- Medium Difficulty recipes
- Pashtun recipes
- Recipes
- Recipes for flatbread
- Recipes using all-purpose flour
- Recipes using corn oil
- Recipes using egg yolk
- Recipes using sugar
- Recipes with metric units
- Vegetarian recipes
---

# Afghan Bread

**Afghan bread** or **Nan-i-Afghani** is the national bread of Afghanistan. It is a flatbread and can be oval or rectangular. It is baked in a tandoor, the primary cooking equipment of the sub-continent region. The Afghan tandoor sits above ground and is round and made of bricks, which are heated to cook the bread. Afghan bread, also known as "nan breads", are shaped, then stuck onto the sides of the oven to bake. Often black cumin seeds or caraway seeds are sprinkled on Afghan bread for decoration as much as taste, and lines are made in the dough lengthwise to add texture to the bread. Afghan bread is similar to pita or Lebanese bread.

Afghan bread is commonly stocked at Middle Eastern grocery stores in western countries. In Afghanistan the baker still cooks the bread the traditional way by spreading the dough around the tandoor, whereby it gets puffy quickly and starts to colour and emit a fresh bread smell that draws the early morning throngs of people. The baker then uses two long iron tongs to pull the bread from the tandoor wall. It is carried in cloth bags by Afghans, unlike western breads packaged in plastic.

Afghans serve bread with most meals; it is used as an equivalent to a fork to envelop foods and soak up liquids on the plate. Generally the bread is torn into shreds and used to pinch the foods, similar to a sandwich. The bread acts as both fork and spoon, as Afghan often use their hands to eat. The bread has no firm crust and tastes similar to Indian naan bread. It has a dense and rich taste.

## Ingredients

## Procedure

1. Mix ½ cup water, yeast, and sugar. Let it sit for 10 minutes until foamy.
2. Place flour in a mixing bowl and sprinkle in the salt. Make a well, then add oil and yeast mixture. Stir in add small amounts of the remaining water until it forms a soft dough that can be moulded. Knead for 5 mins. Cover with paper and let rise for 1½ hours.
3. Mix together the egg yolk and 1 tablespoon of water to make egg wash. Set aside.
4. Divide dough into eight parts and roll each into a ball. Roll each bread into an oval shape 20 cm long and 5 cm thick.
5. Make lines in top of dough. Brush on egg wash, and sprinkle with black cumin seeds.
6. Bake in a preheated 350°F (175°C) oven for 25 mins. Total cooking time is around 2½ hours.
