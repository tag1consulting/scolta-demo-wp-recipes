---
title: Kwek-Kwek (Deep-Fried Quail Eggs)
slug: kwek-kwek-deep-fried-quail-eggs
source_url: https://en.wikibooks.org/wiki/Cookbook:Kwek-Kwek_(Deep-Fried_Quail_Eggs)
source: Wikibooks Cookbook
license: CC-BY-SA 3.0
wikibooks_id: 464693
date: '2025-07-22'
cuisine: []
course: []
diet: []
difficulty: ''
technique: []
recipe_type: []
ingredients: []
---

# Kwek-Kwek (Deep-Fried Quail Eggs)

**Kwek-kwek** is a bite-sized and tempura-like street food of the Philippines.

## Ingredients

- Hard-cooked quail eggs, peeled
- 1 cup water
- 1 cup all-purpose flour
- Orange food coloring or annatto
- Vegetable oil

## Equipment

- Pot and stove or electric fryer
- Whisk or other stirring implement
- Slotted spoon or tongs

## Procedure

1. Gradually but vigorously whisk the water into the flour. The wet mixture should be thick but flow like a pancake batter.
2. Dip the eggs in the batter to coat them completely.
3. Heat several inches of vegetable oil in a deep pot. You're aiming for about 350°F (180°C).
4. Add the coated eggs to the hot oil, and deep fry until very light golden and cooked through. Remove from the oil and drain off any excess.
5. Serve with spicy vinegar.

## Notes, tips, and variations

- The chicken egg variant is called *tokneneng*.
