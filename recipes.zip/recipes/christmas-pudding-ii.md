---
title: Christmas Pudding II
slug: christmas-pudding-ii
source_url: https://en.wikibooks.org/wiki/Cookbook:Christmas_Pudding_II
source: Wikibooks Cookbook
license: CC-BY-SA 3.0
wikibooks_id: 447937
date: '2025-10-26'
cuisine: []
course: []
diet: []
difficulty: ''
technique: []
recipe_type: []
ingredients: []
---

# Christmas Pudding II

**Christmas pudding** is a dessert served typically around the Christmas festive period and on Christmas day in the United Kingdom and other Commonwealth countries such as Australia, New Zealand, South Africa, and Canada. Outside of this festive period, it is known as a plum pudding which can have further recipe variations as well.

The following is a Sussex recipe for Christmas pudding that is known to have been in annual use for over 50 years without a break, and is believed to have been used largely unaltered since the late nineteenth century, despite the difficulties in gathering the ingredients during the rationing in force in the UK in two world wars. All measurements are in imperial units (with metric measurements in brackets), generally meaning that volume measurements are 20% larger than with the Queen Anne units used in the USA. Originally, twice or even four times these quantities would have been made.

The pudding needs to be made and cooked well in advance, to allow the flavours to mix (and to save the cook labour on Christmas Day); it is merely reheated when it is to be eaten.

## Ingredients

- ½ lb (225 g) raisins
- ¾ lb (340 g) currants
- ½ lb (225 g) sultanas
- ½ lb (225 g) white granulated sugar (or less)
- ¾ lb (340 g) shredded suet (can be vegetarian; see note below)
- ½ lb (225 g) breadcrumbs
- ¼ lb (110 g) crystallised peel
- 2 tsp cinnamon
- 2 oz (55 g) almonds, chopped but not too small
- ⅓ cup (about 60 g) flour
- ⅓ pint (about 190 ml) milk
- 3 large eggs, beaten
- Brandy
- Juice and rind of 1 lemon
- ⅓ nutmeg pod, grated

## Procedure

1. Mix all ingredients together, stirring well to combine.
2. Divide batter between 2 pudding basins. Cover with cloths or buttered greaseproof paper, tied tightly in place with string.
3. Steam for 7 hours, then cool and keep until Christmas Day.
4. To prepare for serving, steam for 2 hours. Times can be reduced by using a pressure cooker.

## Notes, tips, and variations

- Suet can be difficult to find in some countries, like the USA. Butter is an excellent substitute. To incorporate the butter in the mixture, melt it in a microwave or saucepan, and pour into your mixing bowl.
- It was common practice to include small silver coins in the pudding mixture, which could be kept by the person whose serving included them. The usual choice was a silver 3d piece (the threepence), or a sixpence. However this practice fell away once real silver coins were not available, as it was believed that alloy coins would taint the pudding.

- Once turned out of its basin, the Christmas pudding is traditionally decorated with a spray of holly, then dowsed in brandy, flamed, and brought to the table ceremonially, where it should be greeted with a round of applause. It is best eaten with brandy butter, cream (lemon cream is excellent), or custard. Christmas puddings keep very well, and many families keep one back from Christmas to be eaten at another celebration later in the year.
