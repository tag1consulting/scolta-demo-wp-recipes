---
title: Paella Valenciana
slug: paella-valenciana
source_url: https://en.wikibooks.org/wiki/Cookbook:Paella_Valenciana
source: Wikibooks Cookbook
license: CC-BY-SA 3.0
wikibooks_id: 4958
date: '2025-12-10'
cuisine:
- Mediterranean
- Spanish
course: []
diet: []
difficulty: Medium Difficulty
technique: []
recipe_type: []
ingredients:
- chicken
- food coloring
- garlic
- green bell pepper
- rice
categories:
- Mediterranean recipes
- Medium Difficulty recipes
- Recipes
- Recipes using chicken
- Recipes using food coloring
- Recipes using garlic
- Recipes using green bell pepper
- Recipes using rice
- Spanish recipes
---

# Paella Valenciana

***Paella Valenciana*** and its seafood variation are authentic Valencian recipes that originated in their modern form in the early 1800s in Spain's Valencian region near lake Albufera. Prior to the 19th century the ingredients for Valencian paella varied greatly with the most unusual being marsh rat. Valencians consider only Valencian paella and seafood paella as true paellas. They view all other variations as impostors. This recipe is based on the ones provided on the Wikipaella.org website, which includes the recipes of prominent Valencian chefs.

Please read *Paella cooking techniques* before attempting this recipe.

## Equipment

- 38-centimeter (15-inch) *paellera*
- 7.6-liter (2-gallon) pot
- Rice skimmer
- Sharp chopping knife for meat and vegetables
- Large serving spoon
- Clean, white towel large enough to cover the *paellera*
- Wide heating source such as:
  - Stove large enough to accommodate the size of the *paellera*
  - Gas burner designed specifically for *paelleras*
  - Charcoal barbecue
  - Low, forged steel tripod to support the *paellera* over a wood or charcoal fire
  - Cinder blocks or heat-resistant bricks to support the *paellera* over a wood or charcoal fire

## Ingredients

- 500 g (17.5 ounces) chicken
- 500 g (17.5 ounces) rabbit or duck
- 20 g (0.75 ounce) salt
- 8 tablespoons olive oil
- 250 g (10 ounces) chopped green bell peppers (optional)
- 1 clove garlic (optional)
- 1 tablespoon sweet paprika
- 500 g (17.5 ounces) diced or grated tomatoes
- 2 liters (2 quarts) water (preferably hard water)
- 24 boiled snails (optional)
- 125 g (4.5 ounces) large haricot beans (canned or fresh)
- 100 g (3.5 ounces) small haricot beans (canned or fresh)
- 125 g (4.5 ounces) fresh runner beans or green beans
- 8–10 threads of saffron and/or 1½ teaspoons yellow food coloring (see notes)
- 400 g (14 ounces) calasparra rice, bomba rice, or pearl rice
- 6–8 branches of fresh rosemary

## Procedure

1. Clean the snails, poultry and rabbit thoroughly. Cut the poultry and rabbit into small pieces and salt them generously.
2. Pour olive oil in a *paellera* and, when hot, sauté the poultry and rabbit pieces until golden brown.
3. Add green peppers and sauté for 1 minute. Add the garlic and sauté until brown. Be careful; garlic burns easily.
4. Once the garlic is brown, add the paprika followed quickly by the tomatoes to prevent the paprika from burning. Sauté until the tomatoes become dark and pulpy and the mixture has reduced a bit.
5. Add the water and bring it to a rolling boil. Then add the snails, fresh haricot beans (if canned, continue reading to see when to add these), runner beans, and saffron (and/or food coloring). Allow the mixture to boil for 10 minutes over a high flame. Sweep a rosemary branch through the broth for no longer than 30 seconds and then remove it.
6. After 10 minutes have passed, you should have a flavorful broth. It's customary at this point to allow your dinner guests to taste it. The purpose is to determine if the broth needs more salt. If so, add more salt, a pinch at a time, until everybody is satisfied.
7. Add the rice and stir it using the rice skimmer. Then, once again with the skimmer, spread the rice over the bottom of the *paellera*. The coating of rice should be one centimeter thick. Let it cook over a high flame for 10 minutes.
8. Reduce the heat to medium and let it simmer for 4 minutes. Add the canned haricot beans, reduce the heat again to low, and let it simmer for another 4 minutes. Taste the rice frequently to determine when it's fully cooked. You'll know it's done when it's slightly firm to the bite. Italians use a similar approach when cooking pasta, which they refer to as *al dente*.
9. At this point, there should be some toasted rice sticking to the bottom of the pan. This is a delicacy in Valencia called *socarrat*. If no *socarrat* has developed, increase the flame to high and listen for the crackling sound of rice toasting at the bottom.
10. Remove the pan from the heat when the rice is almost dry, and place the unused rosemary branches on top. Cover with a clean, white towel (a white towel prevents dye from leeching onto the paella) and wait 5 minutes before serving to allow the rice to absorb the remaining broth.

## Notes, tips, and variations

- Throughout history, saffron has been the natural ingredient used in Spain to color rice yellow. However, it's very expensive because it's labor-intensive to process, and each saffron crocus yields a minuscule amount of saffron. Consequently, supermarkets sell only a few grams per container. Cooks and chefs in Spain (and throughout Latin America) solve this problem by using yellow food coloring, sometimes mixed with seasoning, which is much more affordable.

## See also

- Mastering the art of cooking paellas

## References
