---
title: One-Hour Thanksgiving Dinner
slug: one-hour-thanksgiving-dinner
source_url: https://en.wikibooks.org/wiki/Cookbook:One-Hour_Thanksgiving_Dinner
source: Wikibooks Cookbook
license: CC-BY-SA 3.0
wikibooks_id: 3362
date: '2026-04-22'
cuisine: []
course:
- Dinner
diet: []
difficulty: Easy
technique: []
recipe_type: []
ingredients:
- cooking spray
- cranberry
- turkey
categories:
- Dinner recipes
- Easy recipes
- Recipes
- Recipes using cooking spray
- Recipes using cranberry
- Recipes using turkey
- Thanksgiving recipes
---

# One-Hour Thanksgiving Dinner

This recipe is for an entire **thanksgiving dinner** that takes one hour to cook. The recipe uses various pre-cooked ingredients and instant foods, and is designed for those cooking Thanksgiving dinner for the first time, such as college students.

## Ingredients

- 1 ea. 5–6 lb fully pre-cooked smoked turkey breast (see notes)
- 2 cans of desired vegetables
- 1–2 package(s) of instant potatoes or stuffing
- 1 package of 12 instant frozen biscuits
- 1 package of turkey gravy mix
- Nonstick cooking spray or vegetable oil

- 1 pre-made pumpkin pie (optional)
- 1–2 cans cranberry sauce (optional)

## Equipment

- 1 small disposable aluminum turkey pan with built-in rack
- Probe thermometer

## Procedure

1. Thaw the frozen turkey breast for one day in the refrigerator.
2. Preheat the oven to 350°F.
3. Remove turkey from bag and place in aluminum roasting pan. Spray the turkey with cooking spray, or rub the breast with it vegetable oil.
4. Place turkey breast in the oven on the middle rack, and cook for 15 minutes.
5. Begin preparing the gravy mix according to package directions.
6. Place the vegetables on the stove over low heat.
7. Prepare the instant potatoes or stuffing according to the package directions.
8. On a small pan lay out your frozen biscuits allowing them to touch one another. At this point the turkey breast should have been cooking for 30 minutes.
9. Place the frozen biscuits on the lower rack of the oven. The biscuits will cook just fine with the turkey in the oven and will be ready in 25–30 minutes. Check them after 20 minutes to be sure they do not burn.
10. Finish preparing your instant potatoes or stuffing, instant gravy, and vegetables. Place them in serving dishes if desired.
11. Place the cranberry sauce in a serving dish. If you are serving pie along with the dinner you will also need to place the pie on a serving dish. If a frozen pie has been purchased, follow the instructions for reheating
12. After 1 hour of cooking, remove the turkey and check the internal temperature with a thermometer to make sure it has reached 160°F (the minimum temperature necessary to kill any remaining bacteria).
13. Carve the turkey and serve with all of the prepared side dishes.

## Notes, tips, and variations

- Turkey breast: certain brands are readily available in almost every U.S. supermarket, but they must be fully-cooked frozen turkey breast, as they will only be cooked for 1 hour. The words "heat and serve" may be on the package. Avoid processed turkey breast loaf.
- Biscuits: The frozen home-baked butter variety works best. It is important that the biscuits in a can are not used.
- There are many uses for the leftover turkey. Sliced turkey leftovers can be used to make sandwiches or turkey biscuits.
- The portion along the bone can be used to prepare turkey soup by placing it in a soup pot along with 4 cups of water, 1 chopped onion, 2 tablespoons salt, and pepper to taste. Bring to a boil, then lower the heat and allow to simmer for 2 hours. Add another cup of water, spices to taste, vegetables such as carrots or potatoes, and noodles. Simmer for an additional hour and a half.
