---
title: North Staffordshire Oatcakes
slug: north-staffordshire-oatcakes
source_url: https://en.wikibooks.org/wiki/Cookbook:North_Staffordshire_Oatcakes
source: Wikibooks Cookbook
license: CC-BY-SA 3.0
wikibooks_id: 34645
date: '2025-07-22'
cuisine:
- English
course: []
diet: []
difficulty: Medium Difficulty
technique: []
recipe_type:
- pancakes
ingredients:
- milk
- oat
- sugar
- wheat flour
categories:
- English recipes
- Medium Difficulty recipes
- Recipes
- Recipes for pancakes
- Recipes using milk
- Recipes using oat
- Recipes using sugar
- Recipes using wheat flour
- Recipes with metric units
---

# North Staffordshire Oatcakes

An **oatcake** is a type of pancake made from oatmeal, cooked on a griddle. North Staffordshire oatcakes are a local delicacy in the North Staffordshire (Stoke-on-Trent) area of England, and so may be known to non-locals as a *North Staffordshire oatcake* or *Potteries oatcake*. These use flour and yeast, whereas other oatcakes do not. When pre-cooked, they are a form of fast food, and catering outlets in the area usually offer oatcakes with fillings such as cheese, bacon, sausage and egg. They can be re-heated by frying in butter, or by grilling. In addition, pikelets are often served alongside oatcakes in a similar fashion.

## Ingredients

- 220 g (1 cup or 8 oz) fine oatmeal
- 220 g (1 cup or 8 oz) wholemeal or plain flour
- 1 tsp salt
- 14 g (2 ½ tsp or ½ oz) fresh yeast
- 850 ml (3 ½ cups or 1 ½ pints) warm milk and water, mixed half and half
- 1 tsp sugar

## Procedure

1. Add the salt to the flour and oatmeal.
2. Dissolve the yeast with a little warm liquid and add the sugar. Allow the mixture to become frothy.
3. Mix the dry ingredients with the yeast liquid to make a batter.
4. Cover the batter with a clean cloth and leave it in a warm place for an hour.
5. Cook the oatcakes on a well-greased griddle. Put enough batter onto the griddle to produce an oatcake about 8–9 inches in diameter. The surface will be covered in holes as it cooks.
6. Flip the oatcake after 2–3 minutes when the upper side appears dry and the underneath is golden brown, and cook for another 2–3 minutes.
