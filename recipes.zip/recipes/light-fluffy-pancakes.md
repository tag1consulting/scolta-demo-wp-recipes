---
title: Light Fluffy Pancakes
slug: light-fluffy-pancakes
source_url: https://en.wikibooks.org/wiki/Cookbook:Light_Fluffy_Pancakes
source: Wikibooks Cookbook
license: CC-BY-SA 3.0
wikibooks_id: 112811
date: '2025-07-22'
cuisine: []
course:
- Breakfast
diet:
- Vegetarian
difficulty: Easy
technique:
- Pan fried
recipe_type:
- pancakes
ingredients:
- all-purpose flour
- baking powder
- baking soda
- butter
- buttermilk
- cow milk
- egg
- sugar
- vegetable oil
categories:
- Breakfast recipes
- Easy recipes
- Inexpensive recipes
- Pan fried recipes
- Recipes
- Recipes for pancakes
- Recipes using all-purpose flour
- Recipes using baking powder
- Recipes using baking soda
- Recipes using butter
- Recipes using buttermilk
- Recipes using cow milk
- Recipes using egg
- Recipes using sugar
- Recipes using vegetable oil
- Vegetarian recipes
---

## Ingredients

- 1 cup all-purpose bleached flour
- 2 teaspoons sugar
- ½ teaspoon salt
- ½ teaspoon baking powder
- ¼ teaspoon baking soda
- ¾ cup buttermilk
- ¼ cup milk
- 1 large egg
- 2 tablespoon unsalted butter, melted
- 1 teaspoon vanilla extract
- Vegetable oil for brushing griddle

## Procedure

1. Heat a large non-stick skillet or griddle over low heat while preparing ingredients.
2. Mix flour, sugar, salt, baking powder, and baking soda in medium bowl.
3. Microwave buttermilk and milk in a 2-cup Pyrex measuring cup until room temperature (20–30 seconds).
4. Whisk in egg, butter, and vanilla.
5. Add wet ingredients to dry ingredients and whisk until just mixed.
6. Return batter to measuring cup, stirring in 1–2 teaspoons water if necessary to make a thick but pourable batter.
7. Increase heat to medium and generously brush skillet or griddle with oil.
8. When oil starts to spider, but before it starts to smoke, ladle in batter about ¼ cup at a time to make pancakes. Work in batches, if necessary, to avoid overcrowding.
9. When pancake bottoms are golden brown and tops start to bubble (2–3 minutes), flip pancakes.
10. Cook until pancakes are golden brown on remaining side.
11. Repeat, brushing skillet or griddle with oil between batches of pancakes.
12. Serve hot.

## Notes, tips, and variations

- Use bleached flour to make a tender pancake.
- If using salted butter, reduce salt to ¼ teaspoon.
- Pancake batter should pour, not glug! On the other hand, runny batter makes thin, oddly-shaped pancakes that frequently collide on the griddle. Stir in a touch more flour into thin batter. For batter that's too thick, whisk in water a teaspoon at a time.
- The temperature of the pan or griddle is important: too hot and the pancakes are dark and raw; too cool and they're blond and hard. For tender, golden brown pancakes, heat the pan or griddle on low while you make the batter. Then increase the heat to medium and generously brush the pan or griddle with oil. It's ready when the oil starts to shimmer and, in any skillet or griddle other than non-stick, sends out tendrils that resemble an octopus or spider. But if the pan starts to smoke, set it down off the burner until the smoking subsides and the oil cools a bit.
- This recipe easily doubles for a crowd.
