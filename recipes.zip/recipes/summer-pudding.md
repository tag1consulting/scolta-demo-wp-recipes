---
title: Summer Pudding
slug: summer-pudding
source_url: https://en.wikibooks.org/wiki/Cookbook:Summer_Pudding
source: Wikibooks Cookbook
license: CC-BY-SA 3.0
wikibooks_id: 126203
date: '2025-10-26'
cuisine:
- English
course:
- Dessert
diet: []
difficulty: Easy
technique: []
recipe_type:
- pudding
ingredients:
- berries
- blackcurrant
- bread
- lime zest
- mint
- raspberry
- superfine sugar
categories:
- Easy recipes
- English recipes
- Recipes
- Recipes for dessert
- Recipes for pudding
- Recipes using berries
- Recipes using blackcurrant
- Recipes using bread
- Recipes using lime zest
- Recipes using mint
- Recipes using raspberry
- Recipes using superfine sugar
---

# Summer Pudding

**Summer pudding** is a quintessentially British dessert made from wonderful fresh ingredients only available in the summer months. It is redolent of a private dinner at a smart country house, maybe somewhere in the Surrey hills near Shere, with the taste of an exquisite first course still lingering, a bottle of chilled champagne still half full, and the prospect of more enticing conversation to come as the evening turns into night. Once you make it once, you'll make it again and again!

## Ingredients

- 1 punnet strawberries, large ones halved
- 1 punnet raspberries
- ½ punnet blackcurrants
- ½ punnet redcurrants
- 1 loaf of white, pappy sort of bread or brioche, crusts removed and sliced
- 2 tbsp caster sugar
- 1 lime, finely zested
- 2–3 mint leaves, finely chopped
- 1 bottle of the best quality blackcurrant cordial you can find, in reserve

## Procedure

1. Liberally butter the inside a pudding bowl about 5 inches in diameter. The bowl should preferably not be greater in diameter that the size of your pieces of sliced bread. If you are worried about getting the whole thing out of the bowl in one piece, line the bowl first with some cling film. It's a fiddly job, but ensures you get a perfect shape at the end.
2. Combine the blackcurrants, redcurrants, mint leaves, lime zest, sugar, and about 3 tbsp water. Poach them for about 5 minutes on the lowest possible heat setting of your stove. Add the strawberries and poach for another minute.
3. Turn the heat off and add the raspberries. Leave to cool.
4. Using the prepared bowl as a guide, cut a circle out of the white bread the same diameter as the top of the bowl. Do the same with the bottom of the bowl.
5. Using a sharp knife, slice the bread into squares or oblongs, roughly the same height as the bowl, which will be used to line the inside of the bowl. This does not have to be an exact science. In simple terms what we are trying to do is to line the bowl with the white bread.
6. Lay the smaller circle of white bread on the bottom of the bowl. Put the oblongs of white bread up the side of the bowl, overlapping slightly, and pour the fruit mixture into the void right up to the top. The bread should become well soaked in the juice from the cooked fruit. Indeed if there is not enough juice to soak the bread so it turns very red, use the cordial as a top-up.
7. Place the large circle, or disc, of bread on the top and press it down well.
8. Top with a weight or something that fits into the top of the bowl so it squashes everything down tight, and place it in the fridge for at least 40 minutes.
9. When you are ready to serve the pudding, carefully using a knife to release the bread mould from the side of the bowl, and invert the whole thing onto a plate. If things become a little fraught and wobbly at this point, don't panic—just sort of whack everything back into shape using a wooden spoon.
10. Decorate your plate with some more summer fruit, maybe a couple of mint leaves, and an artistic dollop of fresh whipped cream or crème fraîche, then serve with a flourish.
