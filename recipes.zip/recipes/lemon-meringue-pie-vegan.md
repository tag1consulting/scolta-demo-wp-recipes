---
title: Lemon Meringue Pie (Vegan)
slug: lemon-meringue-pie-vegan
source_url: https://en.wikibooks.org/wiki/Cookbook:Lemon_Meringue_Pie_(Vegan)
source: Wikibooks Cookbook
license: CC-BY-SA 3.0
wikibooks_id: 298889
date: '2026-02-08'
cuisine: []
course:
- Dessert
diet:
- Vegan
difficulty: Medium Difficulty
technique: []
recipe_type:
- lemon meringue pie
ingredients:
- agar
- baking powder
- cornstarch
- granulated sugar
- guar gum
- lemon juice
- lemon zest
- potato starch
- tapioca starch
categories:
- Medium Difficulty recipes
- Recipes
- Recipes for dessert
- Recipes for lemon meringue pie
- Recipes using agar
- Recipes using baking powder
- Recipes using cornstarch
- Recipes using granulated sugar
- Recipes using guar gum
- Recipes using lemon juice
- Recipes using lemon zest
- Recipes using potato starch
- Recipes using tapioca starch
- Vegan recipes
---

## Ingredients

- 1 baked vegan pie crust

### Filling

- 1¼ cup white granulated sugar
- ½ cup cornstarch
- ¼ teaspoon agar
- ¼ teaspoon salt
- 1 ¼ cup non-dairy milk
- 1 cup cold water
- ¾ cup fresh lemon juice
- 1 ½ tablespoons lemon zest
- ⅛ teaspoons turmeric

### Meringue

- 9 teaspoons tapioca starch
- 9 teaspoons potato starch
- 1 ½ teaspoon baking powder
- ¾ teaspoons guar gum
- ½ cup + 2 tablespoons cold water
- ½ cup white granulated sugar
- ¾ teaspoons lemon juice

## Procedure

### Filling

1. Add all the filling ingredients to a saucepan, bring to boil, and whisk for a few minutes. When you can’t stir anymore it’s ready.
2. Keep the filling warm and covered while preparing the meringue.

### Meringue

1. Combine the starches, baking powder, guar gum, lemon juice, and about half the water. Whip by hand until stiff peaks start to form.
2. Add the rest of the water and the sugar slowly, and mix. It should be thick enough that it will have stiff peaks that don’t fall. If it is not thick enough, mix in a little more tapioca starch.

### Pie

1. As soon as the meringue is done, pour the filling into the pie crust. While the filling is hot, spread meringue over filling, carefully sealing to edge of crust. Using a rubber spatula, touch flat side of spatula on meringue and pull away. Repeat over entire surface of meringue.
2. Bake in a 350 °F (180 °C) oven for 10–15 minutes. Cool on rack for 1 hour.
3. Serve at room temperature or chilled.

## Warnings

- The pie filling is quite hot when pouring it into pie shell.
