---
title: Placenta with Broccoli
slug: placenta-with-broccoli
source_url: https://en.wikibooks.org/wiki/Cookbook:Placenta_with_Broccoli
source: Wikibooks Cookbook
license: CC-BY-SA 3.0
wikibooks_id: 29710
date: '2025-06-11'
cuisine: []
course: []
diet: []
difficulty: ''
technique: []
recipe_type: []
ingredients:
- broccoli
- placenta
categories:
- Recipes
- Recipes using broccoli
- Recipes using placenta
---

# Placenta with Broccoli

This dish can go well served with rice, especially if the rice is loose and firm.

You'll need about 1/2 the placenta of a 6.2 pound baby, or 1/3 the placenta of a 9.3 pound baby. Chopped and packed, this is just a bit more than 1/3 cup. (Like any raw meat, you don't exactly chop it — try snipping away at it with kitchen scissors)

## Ingredients

- 1/3 cup chopped fresh human placenta
- 2/3 cup chopped broccoli
- 2 egg whites
- 1/8 teaspoon thyme
- oil for frying

## Procedure

1. Wash the placenta well, in a colander, then shake it to drain. (it will still leak juices)
2. Stir the egg whites with a fork until they are without lumps.
3. Mix all ingredients well, squishing them by hand.
4. Add a decent amount of oil to a suitable frying pan.
5. Set a burner to high heat, and put the pan on it.
6. Start frying, stirring as if stir-frying or scrambling an egg.
7. The small amount of liquid (seeping from the placenta, plus the egg whites) will come to a boil. You might turn down the heat slightly at this point.
8. Let the liquid boil away and/or solidify onto the broccoli and placenta.
9. When it looks finished, serve it.

## Warning

As with any meat from uncontrolled sources (such as hunting or scavenging) people should be cautious of risks involved. Certain blood borne diseases can live in blood and tissue outside the body for some time. Be sure that sensible precautions have been taken.
