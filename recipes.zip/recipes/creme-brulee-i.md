---
title: Crème Brûlée I
slug: creme-brulee-i
source_url: https://en.wikibooks.org/wiki/Cookbook:Cr%C3%A8me_Br%C3%BBl%C3%A9e_I
source: Wikibooks Cookbook
license: CC-BY-SA 3.0
wikibooks_id: 3557
date: '2025-10-26'
cuisine: []
course:
- Dessert
diet:
- Naturally gluten-free
difficulty: Difficult
technique: []
recipe_type:
- caramel
- custard
ingredients:
- egg yolk
- heavy cream
- white sugar
categories:
- Difficult recipes
- Naturally gluten-free recipes
- Recipes
- Recipes for caramel
- Recipes for custard
- Recipes for dessert
- Recipes using egg yolk
- Recipes using heavy cream
- Recipes using white sugar
- Recipes with metric units
---

# Crème Brûlée I

This recipe for **crème brûlée** should provide a crackly crust over a cold custard, balanced in sweetness, egg and cream content. The procedure is due to Dawn Yanagihara. For additional information on the dish, see the crème brûlée disambiguation page.

## Ingredients

## Procedure

1. With the oven rack adjusted to its lower middle position, preheat the oven to 300°F (150°C). Fold a kitchen towel to cover the bottom of a large roasting pan and arrange 12 ea. 5-ounce (150 ml) ramekins on the towel. The ramekins should not touch each other or the side of the roasting pan. If the roasting pan is not large enough, scale down the recipe.
2. Combine 3 cups of the cream and sugar in a medium saucepan. With a paring knife, halve the vanilla beans lengthwise and scrape the seeds into the saucepan. Submerge the pods in the cream. Bring the mixture to a boil over medium heat, stirring occasionally to dissolve the sugar. Remove the saucepan from the heat and steep the mixture for 20 minutes to infuse the flavor.
3. Meanwhile, separate the eggs, placing the yolks in a large bowl and storing the whites for another use. Bring a kettle of water to a boil. After the cream has steeped remove the pods and stir in the remaining 3 cups of cream to cool the mixture.
4. Whisk the egg yolks until they are evenly combined. Add a cup of the cream mixture to the yolks and whisk until combined. Continue adding cups of cream and whisking until evenly colored. Pour the mixture through a fine mesh strainer into a second bowl. Ladle the mixture into the 12 ramekins.
5. Place the roasting pan onto the oven rack and pour in boiling water until it reaches ⅔ the height of the ramekins. Do not splash water into the ramekins. Bake until an instant-read thermometer registers 170–175°F (77–79°C) or until the edges of the custard are set, with a spot in the center about the size of a quarter remaining wiggly. The baking time depends upon the height of the ramekins. If shallow, start checking at 30 minutes. Higher ramekins can take up to an hour to bake.
6. Remove ramekins from roasting pan and cool to room temperature on a wire rack. Place on a shallow tray, cover with plastic wrap, and chill in the refrigerator for at least 4 hours. Before serving, uncover the ramekins and soak up any condensation with paper toweling. Spread 1 teaspoon turbinado sugar on each, tilting and tapping to spread the sugar evenly. Spread sugar only on the number of ramekins that will be served. The others can be stored for several days in the refrigerator for later use.
7. Ignite a propane blowtorch and caramelize the sugar on each ramekin. Take care to direct the flame away from any ignitable material. Avoid the miniature butane torch since its flame is not adequate for uniform caramelization in a reasonable amount of time, and the finished dish may taste of butane. Re-chill the ramekins for not more than 45 minutes. A longer time leads to softening of the caramelized crust.
8. Serve and enjoy!

## Notes, tips, and variations

- Without a torch the sugar may also be caramelized in these ways:
  - After spreading the sugar over the ramekins, place them as close as you can under a very hot broiler. Watch them closely because this method tends to be uneven and burn. Too long under the broiler can also result in the custard turning into a sort of chunky soup which is not a very appealing texture. Works best with fine granulated sugar.
  - Heat the sugar in a saucepan over medium heat without stirring until it starts to melt, then stir with a wooden spoon until caramelization occurs (this is easier to tell with white sugar than Turbinado) and spoon over the ramekins, tilting and rotating them to cover with an even layer.
  - Alternately, combine the sugar with half as much water by volume, bring to a simmer over medium-high heat, and cook without stirring 3 to 5 minutes, tilting the pan as required to ensure even caramelization. If the caramel hardens due to cooling, warm over low heat until it is again pourable.
- Regular granulated sugar may also be used for the caramelization process in place of the brown sugar.
- A towel may also be placed into the roasting pan prior to adding the water to help distribute the heat across the bottom of the ramekins evenly as well as insulate the bottoms from the heat coming through the bottom of the pan.
- Make sure that before adding the cream to the egg yolks, the cream has cooled down. If one adds hot cream, the yolks will start to clot, ruining the final product.
- It is possible to substitute half-and-half or milk for the cream, provided that a few more egg yolks are added for texture.

## References

*Delia Smith's Complete Cookery Course* by Delia Smith (BBC 1997) ISBN 0-563-36249-9 p.482

*History of the Sweet Tooth* (Taylor Piercefield, Taste of Home, 2005)

## See also
