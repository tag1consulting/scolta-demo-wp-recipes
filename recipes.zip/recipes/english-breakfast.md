---
title: English Breakfast
slug: english-breakfast
source_url: https://en.wikibooks.org/wiki/Cookbook:English_Breakfast
source: Wikibooks Cookbook
license: CC-BY-SA 3.0
wikibooks_id: 71932
date: '2025-12-30'
cuisine:
- English
course:
- Breakfast
diet: []
difficulty: ''
technique:
- Pan fried
recipe_type: []
ingredients:
- bacon
- bread
- egg
- sausage
categories:
- Breakfast recipes
- English recipes
- Pan fried recipes
- Recipes
- Recipes using bacon
- Recipes using bread
- Recipes using egg
- Recipes using sausage
---

# English Breakfast

The traditional **English breakfast** is ubiquitous the world over. Cafés and hotels all around the world offer a version, often far removed from what might be considered conventional.

The English breakfast as it is known today is based, like so many British traditions, on what became popular in the Victorian era. Victorian home economist Isabella Beeton gives the following advice in *The Book of Household Management* (1861) about breakfast:

The key components of a modern English breakfast include bacon, sausages, fried or poached eggs, sliced fried red tomatoes, baked beans (in cans), fresh sautéed mushrooms, fried or roast potatoes, fried bread, and black pudding. It may often include stewed prunes, buttered toast, often spread with orange marmalade, tea, and/or orange juice.

The English breakfast frequently suffers from being prepared badly and with poor quality ingredients. Cooked well, with high quality ingredients, it can be a delicious start to the day. Preparing an English breakfast is quite easy; it is basically a matter of starting off cooking the items that take the longest to cook, and moving through to the things that take the least time so that it is all ready at the same time. It is made even easier by the fact that most of the ingredients can be kept warm for a while once cooked without spoiling; this fact allows for the common way of serving English breakfasts as a kind of buffet where diners can help themselves from warm serving plates.

## Ingredients

- 4 rashers of bacon (smoked bacon without too much fat is best, e.g. smoked back bacon)
- 4 eggs
- 4 English-style pork sausages
- 4 medium-sized tomatoes, halved around the equator
- 400 g mushrooms, sliced
- 4–8 slices of bread (traditionally white)
- 1 tin baked beans (optional)

## Procedure

### Method 1

This method emphasizes broiling and poaching rather than frying.

1. Heat a broiler to medium heat, and cook the sausages under it, turning frequently. They should take about 10–15 minutes total to cook.
2. Cover the base of a frying pan with about 1cm of water, and heat on a high heat until boiling. When it is boiling, carefully break the eggs into it. If you have cooking rings, you can put these into the water first and then break the eggs into the rings, to prevent the eggs from spreading too much, although really fresh eggs should stay together anyway. Once the eggs are in the pan, wait a few moments for the water to heat up again, then turn the heat down to a very very gently simmer. To ensure the tops of the eggs are cooked, spoon water from around the edge of the pan over the top of the eggs a few times during cooking. When cooked, the egg white should be soft but cooked through and the yolk still runny. They should take about 8–10 minutes to cook.
3. Put the halved tomatoes under the broiler with the sausages. They should take about 6 minutes to cook.
4. If using, put the baked beans into a saucepan and heat through over a medium heat. They should take about 5 minutes to heat through.
5. Heat up a very small amount of oil in a pan, and fry the mushrooms until they are soft. They should take about 4 minutes to cook.
6. Put the bacon under the grill along with the sausages and tomatoes. Cook on one side for about 2 minutes, then turn once and repeat. Cook longer if crispier bacon is preferred. This should take about 4 minutes to cook.
7. Whilst cooking the bacon, toast the bread until golden.
8. Serve the eggs, bacon, mushrooms, sausage, tomato and beans onto piping hot plates, with the toast on a separate plate or toast rack. Serve with butter and jam for the toast, and hot tea with milk.

### Method 2

This method is more in keeping with the spirit of the dish.

1. Start toasting the bread before cooking the rest of the food. Assuming 2 slices per person, you should have enough by the time you finish the fried food. Be sure to butter them heavily with real butter rather than low-fat spread. Place 4 plates on the bottom shelf of an oven, and one on the top. Set the oven to its lowest heat.
2. Melt some lard in a large frying pan (enough to make a layer of fat around 1 cm deep) and brown the sausage in it over a high heat. Lower heat and cook the sausage for around 4 minutes, and leave it in the pan. A lot of fat will leak from the sausages. Add the bacon (2 strips per person rather than 1) and cook to taste, flipping regularly (2–3 minutes for pink, 4–6 for a darker red bacon with crispy fat). The bacon will also release a lot of fat. Transfer the bacon to the warmed dish in the top of the oven. Leave the sausage in the pan.
3. Add the mushrooms and tomatoes to the pan. Add the tin of baked beans to a small pot and heat on a separate burner. After 2–4 minutes, transfer the mushrooms to the oven with the bacon. Transfer the tomato then too, or leave it a little longer depending on taste.
4. The sausages should now be dark brown, push them to the side of the pan and break an egg into the fat. Using a spatula, push hot fat over the yolk until it begins to bubble but is still liquid. This should take about 1 minute or so in a hot pan. Set out the 4 warmed plates beforehand and add an egg to each. When done, add the sausage, bacon, and mushrooms. Add the beans last. Serve with the buttered toast on a separate plate.
5. If you are using black pudding, add it to the fat with the bacon and remove it before the eggs.
6. If you desire a fried slice, add a slice of bread (whole or cut diagonally, in half or quarters) and allow it to absorb some of the leftover fat and lightly fry, then flip over and repeat. Alternatively, you can just fry some bread in vegetable oil in a separate pan but it doesn't have the same flavour as bread fried in the leftover fat from cooking a full breakfast in lard. If a whole slice is used it is preferable to place the fried egg on top, so the yolk runs into the bread and can easily be absorbed by the fried slice.

## Notes, tips, and variations

- You can increase the number of eggs per person if desired.
- If you can't cope with preparing everything all at once (or don't have enough pans / rings), it is possible to keep all of the items warm in a preheated oven, so you can just cook each item in turn and keep it warm until needed. Try not to keep the eggs warm for too long before serving though, as the yolks may harden.
