---
title: OpenCola
slug: opencola
source_url: https://en.wikibooks.org/wiki/Cookbook:OpenCola
source: Wikibooks Cookbook
license: CC-BY-SA 3.0
wikibooks_id: 31311
date: '2026-02-25'
cuisine: []
course: []
diet: []
difficulty: Very Easy
technique: []
recipe_type:
- soda pop
ingredients:
- citric acid
- granulated sugar
categories:
- Recipes
- Recipes for soda pop
- Recipes using citric acid
- Recipes using granulated sugar
- Recipes with metric units
- Very Easy recipes
---

# OpenCola

**OpenCola** is unique in that the instructions for making it are freely available and modifiable. Anybody can make the drink, and anyone can modify and improve on the recipe as long as they, too, license their recipe under the GNU General Public License. The legal grounds for this are dubious however, as recipes are exempted from copyright as they are techniques, not artworks.

Although originally intended as a promotional tool to explain free software/open source software, the drink took on a life of its own and 150,000 cans were sold. The Toronto-based company Opencola founded by Grad Conn, Cory Doctorow and John Henson became better known for the drink than the software it was supposed to promote. Laird Brown, the company's senior strategist, attributes its success to a widespread mistrust of big corporations and the "proprietary nature of almost everything."

As it turns out, mixing up a batch of cola's pretty easy. As with all undertakings of great moment, read and understand the instructions before attempting to commit cola on your own. Note that this is not the recipe for "OpenCola"—that is, the canned beverage from Opencola that you may have received at a trade show, or other venue or outlet. Making canned cola requires millions of dollars in abstruse gear and manufacturing gizmos. It's easier to make nerve gas than manufacture cola. This is a kitchen-sink recipe that you can make all on your own.

## Ingredients

### Flavoring formula

- ¾ tsp (3.50 mL) orange oil
- ½ tsp (2.75 mL) lime oil
- ¼ tsp (1.25 mL) cassia oil
- ¼ tsp (1 mL) lemon oil
- ¼ tsp (1 mL) nutmeg oil
- 0.25 mL (5 drops) coriander oil
- 0.25 mL (5 drops) neroli oil
- 0.25 mL (5 drops) lavender oil
- 2 teaspoons (10.0 g / 10 mL) food-grade gum arabic
- ⅔ teaspoon (3 mL) water

### Concentrate formula

- 11 cups (2.36 kg / 5.2 lb) plain granulated white table sugar
- 9½ cups (2.28 L / 4.41 quarts) water
- 2 tbsp (30 mL) caramel color
- 3½ tsp (17.25 mL) 75% phosphoric acid or citric acid
- 2 tsp (10 mL) Flavoring Formula
- ½ tsp (2.5 mL) caffeine (optional)

## Preparation

### Flavoring

1. Mix oils together in a cup.
2. Add gum arabic, and mix with a spoon.
3. Add water and mix well. A mixer may be used for this step, mixing for 4–5 minutes. You can also transfer to a blender for this step.
4. Store this mixture in a sealed glass jar in a refrigerator or at room temperature. Please note that this mixture will separate. The gum arabic is essential to this part of the recipe, as you are mixing oil and water.

### Syrup

1. In a one gallon container, combine 5 ml of the flavoring formula with the phosphoric or citric acid.
2. Mix in the water, then the sugar.
3. While mixing, add the caffeine, if desired. Make sure the caffeine is completely dissolved.
4. Add the caramel color and mix thoroughly.

### Cola

1. To finish the drink, mix 1 part syrup with 5 parts carbonated water.

## Notes, tips, and variations

- The sugar can be replaced with artificial sweeteners for a diet drink. The opensoda.org formula from 2009 calls for replacement with Splenda at ⅛ the mass of the original sugar amount.
- Try measuring the flavoring oils with an eyedropper.
- Alcohol can be used to aid with mixing the flavoring. Cube-cola instead uses a kitchen whisk attached to power tools.
- Use only food-grade flavoring oils. Note that these oils can cause skin irritation. Wear food-prep or surgical gloves. If oils come in contact with skin, wash with soap and water.
- It is very important that you get only food-grade gum arabic, as art-grade can be toxic.
- 75% phosphoric acid is corrosive to the eyes and skin. Handle with gloved hands, and use extreme caution. If comes in contact with the eyes or skin, immediately flush with plenty of water for at least 15 minutes. Get medical attention. Rinse any spills on clothing or other surfaces thoroughly. Store in a secure area. Do not store more than 50.0 ml.
- Caffeine can kill people in relatively small doses. The median lethal dose for an adult human is around 10 grams, or approximately ⅓ ounce. You can find out more by looking up the material safety data sheet (MSDS) for caffeine. Don't yield to the temptation to create a "Super-Jolt" by adding tons and tons of the white stuff to your cola, or you'll be in a world of hurt. It's best not to store caffeine in any amount. If stored, store in a secure area away from children. Absolutely do not put more than three times the amount of caffeine here (when scaling up or down if you are upscaling or downscaling the recipe).

You can downscale the recipe to suit a home kitchen by using the following ingredient ratios:

### Flavoring formula

- 14 drops orange oil
- 11 drops lime oil
- 5 drops cassia oil
- 4 drops lemon oil
- 4 drops nutmeg oil
- 1 drop coriander oil
- 1 drop neroli oil
- 1 drop lavender oil
- 2.5 mL (½ teaspoon) food-grade gum arabic
- 0.6 mL (⅛ teaspoon) water

### Concentrate formula

- 2¼ cups (532 mL / 472 g / 1.04 lb) plain granulated white table sugar
- 1¾ cups (456 mL / 0.882 quarts) water
- 1 teaspoon (5 mL) caramel color
- ¾ teaspoon (3.45 mL) 75% phosphoric acid or citric acid
- ⅜ tsp (2 mL) Flavoring Formula
- ⅛ tsp (0.5 mL) caffeine (optional)

## References

- OpenCola soft drink
- Cube Cola Bristol UK
- Guardian Newspaper Article
- OpenCola's soft drink formula
- How to Make OpenCola - WikiHow

### Adapted from

- http://alfredo.octavio.net/soft\_drink\_formula.pdf
- View as HTML with Google
- View as images with view.samurajdata.se
