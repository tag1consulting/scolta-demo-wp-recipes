---
title: Edible Cookie Dough
slug: edible-cookie-dough
source_url: https://en.wikibooks.org/wiki/Cookbook:Edible_Cookie_Dough
source: Wikibooks Cookbook
license: CC-BY-SA 3.0
wikibooks_id: 470808
date: '2025-10-18'
cuisine: []
course: []
diet: []
difficulty: ''
technique: []
recipe_type: []
ingredients: []
---

# Edible Cookie Dough

The **edible cookie dough** recipe is safe to eat without worrying about raw flour and eggs.

## Ingredients

- 1 cup (140 g) all-purpose flour
- ½ cup (110 g) butter, softened
- 1 cup (180 g) soft light brown sugar
- 2 teaspoons vanilla extract
- ½ teaspoon salt
- 2 tablespoons milk

## Procedure

1. Preheat the oven to 200 °C (392 °F). Line a baking pan and spread flour onto it. Cook in oven for 5 minutes to kill any harmful bacteria.
   - Alternatively, you can microwave the flour in intervals of 20 seconds, stirring between each interval, until the temperature reaches 75°C (167°F).
2. Cream the butter and sugar in a mixing bowl until light and fluffy.
3. Beat in the vanilla and salt.
4. Add the flour, and mix in until you get a breadcrumb consistency.
5. Gradually add milk, mixing to form a soft dough.
6. Use the edible cookie dough as it is or serve with ice cream or other desserts.

## Notes, tips, and variations

- The edible cookie dough can be stored in refrigerator for up to 4 days.
- You can freeze the edible cookie dough for up to 3 months by rolling into balls, placing on a lined baking pan, freezing until solid (about 2 hours), and transferring to a ziplock bag for long-term storage.
- For salted caramel cookie dough, mix in 1 tablespoon dulce de leche, another ½ teaspoon salt, and a handful of dark chocolate chips.
- For s'mores cookie dough, mix in 1 tablespoon chocolate hazelnut spread, 2 crushed graham crackers and a handful of mini marshmallows.
- For apple and cinnamon cookie dough, mix in 1 tablespoon additional brown sugar and 1 teaspoon ground cinnamon, and dried apple chunks.
- For peanut heaven cookie dough, mix in 1 tablespoon peanut butter and a handful of chocolate-covered peanuts.
- For chocolate cookie dough, mix in 1 tablespoon cocoa powder.
- You can make colored cookie dough by mixing in a few drops of food coloring.
- You can experiment with molding the dough into different shapes.

## References
